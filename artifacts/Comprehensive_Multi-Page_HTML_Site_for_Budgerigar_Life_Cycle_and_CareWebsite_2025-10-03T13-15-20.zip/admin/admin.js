// Admin Panel Logic
const API_BASE = 'YOUR_APPS_SCRIPT_URL'; // Replace with deployed Apps Script URL
let currentSection = 'home';
let editingArticleId = null;

// Auth
document.getElementById('loginBtn').addEventListener('click', login);
document.getElementById('logoutBtn').addEventListener('click', logout);

function login() {
  const token = document.getElementById('tokenInput').value.trim();
  const errorEl = document.getElementById('authError');
  
  if (!token) {
    errorEl.textContent = 'Please enter a token';
    return;
  }
  
  localStorage.setItem('adminToken', token);
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('adminScreen').classList.add('visible');
  loadArticles();
}

function logout() {
  localStorage.removeItem('adminToken');
  document.getElementById('authScreen').style.display = 'flex';
  document.getElementById('adminScreen').classList.remove('visible');
}

// Check auth on load
if (localStorage.getItem('adminToken')) {
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('adminScreen').classList.add('visible');
  loadArticles();
}

// Section selector
document.getElementById('sectionSelect').addEventListener('change', (e) => {
  currentSection = e.target.value;
  loadArticles();
});

// Modal
const modal = document.getElementById('articleModal');
const articleForm = document.getElementById('articleForm');

document.getElementById('addBtn').addEventListener('click', () => {
  editingArticleId = null;
  document.getElementById('modalTitle').textContent = 'Add Article';
  document.getElementById('articleTitle').value = '';
  document.getElementById('articleBody').value = '';
  clearErrors();
  modal.classList.add('visible');
});

document.getElementById('cancelBtn').addEventListener('click', () => {
  modal.classList.remove('visible');
});

articleForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors();
  
  const title = document.getElementById('articleTitle').value.trim();
  const body = document.getElementById('articleBody').value.trim();
  
  // Validation
  let hasError = false;
  
  if (!title) {
    document.getElementById('titleError').textContent = 'Title is required';
    hasError = true;
  }
  
  if (!body || body.length < 50) {
    document.getElementById('bodyError').textContent = 'Body must be at least 50 characters';
    hasError = true;
  }
  
  if (hasError) return;
  
  // Sanitize XSS
  const sanitizedTitle = sanitizeHTML(title);
  const sanitizedBody = sanitizeHTML(body);
  
  const article = {
    id: editingArticleId || `article-${Date.now()}`,
    title: sanitizedTitle,
    body: sanitizedBody,
    updatedAt: Date.now()
  };
  
  try {
    if (editingArticleId) {
      await updateArticle(article);
      showToast('Article updated successfully');
    } else {
      await createArticle(article);
      showToast('Article created successfully');
    }
    
    modal.classList.remove('visible');
    loadArticles();
  } catch (err) {
    showToast('Error: ' + err.message, true);
  }
});

// CRUD operations
async function loadArticles() {
  try {
    const response = await fetch(`${API_BASE}?action=get&section=${currentSection}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('adminToken')}` }
    });
    
    if (!response.ok) throw new Error('Failed to load articles');
    
    const data = await response.json();
    const articles = data.sections[currentSection] || [];
    
    renderArticles(articles);
  } catch (err) {
    showToast('Error loading articles: ' + err.message, true);
  }
}

async function createArticle(article) {
  const response = await fetch(API_BASE, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
    },
    body: JSON.stringify({
      action: 'create',
      section: currentSection,
      article
    })
  });
  
  if (!response.ok) throw new Error('Failed to create article');
  return response.json();
}

async function updateArticle(article) {
  const response = await fetch(API_BASE, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
    },
    body: JSON.stringify({
      action: 'update',
      section: currentSection,
      article
    })
  });
  
  if (!response.ok) throw new Error('Failed to update article');
  return response.json();
}

async function deleteArticle(id) {
  if (!confirm('Are you sure you want to delete this article?')) return;
  
  try {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
      },
      body: JSON.stringify({
        action: 'delete',
        section: currentSection,
        id
      })
    });
    
    if (!response.ok) throw new Error('Failed to delete article');
    
    showToast('Article deleted successfully');
    loadArticles();
  } catch (err) {
    showToast('Error: ' + err.message, true);
  }
}

function renderArticles(articles) {
  const container = document.getElementById('articlesList');
  
  if (articles.length === 0) {
    container.innerHTML = '<p style="color: #666;">No articles yet. Click "Add Article" to create one.</p>';
    return;
  }
  
  container.innerHTML = articles.map(article => `
    <div class="article-card" data-testid="article-${article.id}">
      <h3>${escapeHTML(article.title)}</h3>
      <p>${escapeHTML(article.body.substring(0, 150))}...</p>
      <div class="actions">
        <button class="btn-edit" onclick="editArticle('${article.id}')" data-testid="btn-edit-${article.id}">Edit</button>
        <button class="btn-delete" onclick="deleteArticle('${article.id}')" data-testid="btn-delete-${article.id}">Delete</button>
      </div>
    </div>
  `).join('');
}

function editArticle(id) {
  // Load article data
  fetch(`${API_BASE}?action=get&section=${currentSection}`)
    .then(r => r.json())
    .then(data => {
      const article = (data.sections[currentSection] || []).find(a => a.id === id);
      if (!article) return;
      
      editingArticleId = id;
      document.getElementById('modalTitle').textContent = 'Edit Article';
      document.getElementById('articleTitle').value = article.title;
      document.getElementById('articleBody').value = article.body;
      clearErrors();
      modal.classList.add('visible');
    });
}

// Utilities
function sanitizeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function clearErrors() {
  document.getElementById('titleError').textContent = '';
  document.getElementById('bodyError').textContent = '';
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.style.background = isError ? '#ef4444' : '#1f2937';
  toast.classList.add('visible');
  
  setTimeout(() => {
    toast.classList.remove('visible');
  }, 3000);
}