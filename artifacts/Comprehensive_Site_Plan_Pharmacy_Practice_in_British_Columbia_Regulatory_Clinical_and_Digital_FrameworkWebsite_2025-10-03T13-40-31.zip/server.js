// server.js — minimal static host for live preview
const express = require("express");
const path = require("path");
const app = express();
const SITE_DIR = path.join(__dirname, "site");

app.use(express.static(SITE_DIR, {
  extensions: ["html"], // allows /about to resolve to about.html
  setHeaders: (res, filePath) => {
    if (filePath.endsWith(".html")) {
      res.setHeader("Content-Type", "text/html; charset=utf-8");
    }
  }
}));

app.get("/", (_req, res) => {
  res.sendFile(path.join(SITE_DIR, "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✓ Website running at http://localhost:${PORT}`);
  console.log(`  Open your browser to view the site`);
});